# Changelog

##### 1.1

- *Added*: I forgot that knockout matches can have overtime and penalty results
- *Added*: Updated README to the reflect the knockout match changes

##### 1.0

- Initial data
